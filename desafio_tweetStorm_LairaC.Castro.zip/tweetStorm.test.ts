import { tweetStorm } from './tweetStorm';

//TESTE 1
test('Teste da função tweetStorm', () => {
  const testText =
    "Pagination is a feature in Twitter API v2 endpoints that return more results than can be returned in a single response. When that happens, the data is returned in a series of 'pages'. Pagination refers to methods for programatically requesting all of the pages, in order to retrieve the entire result data set. Not all API endpoints support or require pagination, but it is often used when result sets are large.";
  const result = tweetStorm(testText);
  expect(result).toEqual([
    "1/4 Pagination is a feature in Twitter API v2 endpoints that return more results than can be returned in a single response. When that hap",
    "2/4 pens, the data is returned in a series of 'pages'. Pagination refers to methods for programatically requesting all of the pages, in o",
    "3/4 rder to retrieve the entire result data set. Not all API endpoints support or require pagination, but it is often used when result se",
    "4/4 ts are large."
  ]);
});

//TESTE 2
test('Teste da função tweetStorm', () => {
  const testText = "Z";
  const result = tweetStorm(testText);
  expect(result).toEqual(["1/1 Z"]);
});


