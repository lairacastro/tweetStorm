export function tweetStorm(text: string): string[] {
  const maxTweetLength = 140;
  const pageIndicatorLength = 7;
  const tweetLength = maxTweetLength - pageIndicatorLength
 
  let pages: string[] = [];
  let atualPage = 1;

  while (text.length > 0) {
    let tweet = text.slice(0, tweetLength);
    text = text.slice(tweet.length);    
    pages.push(tweet);
    atualPage++;
  }
  
  const totalPages = pages.length;
  return pages.map((page, index) => `${index + 1}/${totalPages} ${page}`);
}

// Testes
const testText =
"Lorem ipsum dolor sit amet. Et voluptatum magnam est fugiat tenetur et voluptas provident qui fuga tempore id possimus laborum et saepe sequi ut consequatur officia. Eum modi consequatur ex dolorum beatae sit quia molestiae eum impedit dolorum et eaque mollitia sed voluptate quam vel fugit velit. Vel accusamus molestiae vel magni consectetur et error amet eum velit Quis. Ea accusamus deleniti sit veniam voluptas sed commodi voluptatibus et quia deleniti qui temporibus omnis. Et repellendus architecto ex amet autem et distinctio quia hic autem rerum ea ipsam porro qui corrupti eius. Est delectus iure est distinctio dolore ut omnis maxime. Qui reprehenderit sint non expedita rerum et quia tenetur est perferendis quidem eum adipisci dolores. Qui inventore sapiente non facilis ipsum ut velit iste est maxime aliquam. Ad rerum magni sit nisi incidunt et fugit odio aut eligendi molestiae sit voluptas molestias sit voluptatibus omnis. Ab galisum consequuntur ut molestias cupiditate qui harum illo 33 obcaecati enim quo optio quidem?.";

const result = tweetStorm(testText);
console.log(result);
