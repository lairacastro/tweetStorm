"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tweetStorm = void 0;
function tweetStorm(text) {
    var maxTweetLength = 140;
    var atualPage = 1;
    var totalPages = Math.ceil(text.length / (maxTweetLength - 4));
    var tweets = [];
    while (text.length > 0) {
        var tweet = text.slice(0, maxTweetLength - atualPage.toString().length - totalPages.toString().length - 3);
        text = text.slice(tweet.length);
        tweet += " ".concat(atualPage, "/").concat(totalPages);
        tweets.push(tweet);
        atualPage++;
    }
    return tweets;
}
exports.tweetStorm = tweetStorm;
// Testes
var testText =  "Lorem ipsum dolor sit amet. Et voluptatum magnam est fugiat tenetur et voluptas provident qui fuga tempore id possimus laborum et saepe sequi ut consequatur officia. Eum modi consequatur ex dolorum beatae sit quia molestiae eum impedit dolorum et eaque mollitia sed voluptate quam vel fugit velit.";
var result = tweetStorm(testText);
console.log(result);
